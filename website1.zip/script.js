// Parallax Effect
window.addEventListener('scroll', function() {
    const parallax = document.querySelector('.parallax-bg');
    if (parallax) {
      parallax.style.transform = `translateY(${window.scrollY * 0.4}px)`;
    }
  });
  
  // Scroll Animations
  function revealOnScroll() {
    const reveals = document.querySelectorAll('[data-animate]');
    const windowHeight = window.innerHeight;
    reveals.forEach(el => {
      const top = el.getBoundingClientRect().top;
      if (top < windowHeight - 60) {
        el.classList.add('visible');
      }
    });
  }
  window.addEventListener('scroll', revealOnScroll);
  window.addEventListener('DOMContentLoaded', revealOnScroll);
  
  // Ripple Effect
  function createRipple(event) {
    const button = event.currentTarget;
    const circle = document.createElement('span');
    const diameter = Math.max(button.clientWidth, button.clientHeight);
    const radius = diameter / 2;
    circle.style.width = circle.style.height = `${diameter}px`;
    circle.style.left = `${event.clientX - button.getBoundingClientRect().left - radius}px`;
    circle.style.top = `${event.clientY - button.getBoundingClientRect().top - radius}px`;
    circle.classList.add('ripple');
    button.appendChild(circle);
    circle.addEventListener('animationend', () => {
      circle.remove();
    });
  }
  document.querySelectorAll('.ripple-btn').forEach(btn => {
    btn.addEventListener('click', createRipple);
  });
  
  // Testimonial Modal
  const testimonials = [
    {
      name: 'Alex',
      img: 'https://images.unsplash.com/photo-1511367461989-f85a21fda167?auto=format&fit=facearea&w=200&q=80',
      text: 'Absolutely stunning effects! The parallax and ripple are so smooth. Highly recommended for modern web projects.'
    },
    {
      name: 'Jamie',
      img: 'https://images.unsplash.com/photo-1508214751196-bcfd4ca60f91?auto=format&fit=facearea&w=200&q=80',
      text: 'A joy to scroll and interact with. The animations make the site feel alive and engaging.'
    },
    {
      name: 'Taylor',
      img: 'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=facearea&w=200&q=80',
      text: 'Modern, smooth, and beautiful. The testimonial popup is a nice touch!'
    }
  ];
  
  document.querySelectorAll('.testimonial').forEach(el => {
    el.addEventListener('click', function() {
      const idx = parseInt(el.getAttribute('data-testimonial'), 10) - 1;
      const modal = document.getElementById('testimonial-modal');
      const body = document.getElementById('modal-body');
      if (testimonials[idx]) {
        body.innerHTML = `
          <img src="${testimonials[idx].img}" alt="${testimonials[idx].name}" style="width:80px;height:80px;border-radius:50%;margin-bottom:1rem;">
          <h3>${testimonials[idx].name}</h3>
          <p style="margin-top:1rem;">${testimonials[idx].text}</p>
        `;
        modal.classList.add('active');
      }
    });
  });
  document.getElementById('close-modal').addEventListener('click', function() {
    document.getElementById('testimonial-modal').classList.remove('active');
  });
  document.getElementById('testimonial-modal').addEventListener('click', function(e) {
    if (e.target === this) {
      this.classList.remove('active');
    }
  });
  
  // Preloader
  window.addEventListener('load', function() {
    const preloader = document.getElementById('preloader');
    if (preloader) {
      preloader.style.opacity = '0';
      setTimeout(() => preloader.style.display = 'none', 500);
    }
  });
  
  // Theme Toggle
  const themeToggle = document.getElementById('theme-toggle');
  const themeIcon = document.getElementById('theme-icon');
  function setTheme(dark) {
    if (dark) {
      document.body.classList.add('dark');
      themeIcon.textContent = '☀️';
      localStorage.setItem('theme', 'dark');
    } else {
      document.body.classList.remove('dark');
      themeIcon.textContent = '🌙';
      localStorage.setItem('theme', 'light');
    }
  }
  themeToggle.addEventListener('click', () => {
    setTheme(!document.body.classList.contains('dark'));
  });
  window.addEventListener('DOMContentLoaded', () => {
    const saved = localStorage.getItem('theme');
    setTheme(saved === 'dark');
  });
  
  // AI Chat Feature
  const aiBtn = document.getElementById('ai-chat-btn');
  const aiModal = document.getElementById('ai-modal');
  const closeAiModal = document.getElementById('close-ai-modal');
  const aiForm = document.getElementById('ai-chat-form');
  const aiInput = document.getElementById('ai-input');
  const aiHistory = document.getElementById('ai-chat-history');
  
  // Fun/Smart AI responses
  const aiResponses = [
    { keywords: ['hello', 'hi'], response: "Hello! 👋 How can I help you today?" },
    { keywords: ['project', 'website'], response: "This website is built with modern effects and a touch of AI magic!" },
    { keywords: ['who are you', 'your name'], response: "I'm your friendly AI assistant, here to make your web experience awesome!" },
    { keywords: ['inspire', 'motivate'], response: "Believe in yourself! Every great project starts with a single step. 🚀" },
    { keywords: ['effect', 'animation'], response: "Scroll, click, and explore! You'll find parallax, ripples, and more." },
    { keywords: ['thank'], response: "You're welcome! 😊" },
    { keywords: [], response: "I'm here to help! Try asking about the website, effects, or just say hi." }
  ];
  
  function getAIResponse(input) {
    const text = input.toLowerCase();
    for (const entry of aiResponses) {
      if (entry.keywords.some(k => text.includes(k))) {
        return entry.response;
      }
    }
    return aiResponses[aiResponses.length - 1].response;
  }
  
  aiBtn.addEventListener('click', () => {
    aiModal.classList.add('active');
    aiInput.focus();
  });
  closeAiModal.addEventListener('click', () => {
    aiModal.classList.remove('active');
  });
  aiModal.addEventListener('click', (e) => {
    if (e.target === aiModal) aiModal.classList.remove('active');
  });
  aiForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const userMsg = aiInput.value.trim();
    if (!userMsg) return;
    // Show user message
    const userDiv = document.createElement('div');
    userDiv.className = 'ai-message user';
    userDiv.textContent = userMsg;
    aiHistory.appendChild(userDiv);
    aiInput.value = '';
    aiHistory.scrollTop = aiHistory.scrollHeight;
    // AI response
    setTimeout(() => {
      const aiDiv = document.createElement('div');
      aiDiv.className = 'ai-message ai';
      aiDiv.textContent = getAIResponse(userMsg);
      aiHistory.appendChild(aiDiv);
      aiHistory.scrollTop = aiHistory.scrollHeight;
    }, 600);
  });