const infoBox = document.getElementById("feature-info");
let current = 1;

const data = {
  1: {
    title: "Feature 1",
    text: "This is the detail of Feature 1. It appears while Feature 1 is visible in the carousel."
  },
  2: {
    title: "Feature 2",
    text: "Details about Feature 2 are shown here. It syncs as Feature 2 scrolls into view."
  },
  3: {
    title: "Feature 3",
    text: "Feature 3 info appears here. This is displayed as it slides into view."
  }
};

// Rotate content every 5 seconds
setInterval(() => {
  current = current % 3 + 1;
  infoBox.innerHTML = `
    <h2>${data[current].title}</h2>
    <p>${data[current].text}</p>
  `;
}, 5000);
