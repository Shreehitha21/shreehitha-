const wrapper = document.getElementById('carousel-wrapper');
const images = wrapper.getElementsByTagName('img');
const dotsContainer = document.getElementById('dots');

let current = 0;
const total = images.length;

// Generate dots
for (let i = 0; i < total; i++) {
  const dot = document.createElement('span');
  dot.classList.add('dot');
  if (i === 0) dot.classList.add('active');
  dot.addEventListener('click', () => goToSlide(i));
  dotsContainer.appendChild(dot);
}

const dots = document.querySelectorAll('.dot');

function updateSlide() {
  wrapper.style.transform = `translateX(-${current*100}%)`;
  dots.forEach((dot, i) => {
    dot.classList.toggle('active', i === current);
  });
}

function nextSlide() {
  current = (current + 1) % total;
  updateSlide();
}

function prevSlide() {
  current = (current - 1 + total) % total;
  updateSlide();
}

function goToSlide(index) {
  current = index;
  updateSlide();
}

// Optional: Auto slide
setInterval(nextSlide, 4000); // 4 seconds